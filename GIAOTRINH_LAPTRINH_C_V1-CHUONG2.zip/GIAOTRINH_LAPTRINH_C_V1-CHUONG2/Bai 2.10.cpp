#include <bits/stdc++.h>
using namespace std;

int main()
{
    double x, y;
    cin >> x >> y;
    (x > y)? cout << x: cout << y;
    return 0;
}
/*
#include <bits/stdc++.h>
using namespace std;

int main()
{
    double x, y;
    cin >> x >> y;
    if(x > y)
    {
        cout << x;
    }
    else    cout << y;
    return 0;
}
*/
