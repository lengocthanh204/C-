#include <bits/stdc++.h>
using namespace std;

int main()
{
    int a, b, c;
    cin >> a >> b >> c;
    cout << (a + 1)/2 + (b + 1)/2 + (c + 1)/2;
    return 0;
}

