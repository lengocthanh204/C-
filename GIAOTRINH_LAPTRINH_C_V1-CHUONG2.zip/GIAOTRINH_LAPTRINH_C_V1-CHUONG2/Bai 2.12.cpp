#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    cout << n / 10 + n % 10;
    return 0;
}

/*
#include <bits/stdc++.h>

using namespace std;

int main()
{
    int i, chuc, donvi;
    cin >> i;
    chuc = i / 10;
    donvi = i % 10;
    cout << chuc + donvi;
    return 0;
}
*/
