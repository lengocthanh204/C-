#include <bits/stdc++.h>
using namespace std;

int main()
{
    long long m, n, a;
    cin >> m >> n >> a;
    cout << m * n * a << " VND";
    return 0;
}

