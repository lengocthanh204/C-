#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    (n % 2 != 0)? cout << "LE": cout << "CHAN";
    return 0;
}

/*
#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    if(n % 2 != 0)   cout << "LE";
    else    cout << "CHAN";
    return 0;
}
*/

